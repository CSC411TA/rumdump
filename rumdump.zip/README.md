This is a simple binary to disassemble (much like objdump) a Universal Machine binary.

Usage: `rumdump [um_binary]`

If no argument is given, input is expected on STDIN.